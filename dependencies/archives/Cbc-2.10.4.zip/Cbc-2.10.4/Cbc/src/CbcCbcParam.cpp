/* $Id: CbcCbcParam.cpp 2465 2019-01-03 19:26:52Z unxusr $ */
// Copyright (C) 2007, International Business Machines
// Corporation and others.  All Rights Reserved.
// This code is licensed under the terms of the Eclipse Public License (EPL).

#include "CbcConfig.h"
#ifndef COIN_HAS_CBC
#define COIN_HAS_CBC
#endif
#include "CbcOrClpParam.cpp"

/* vi: softtabstop=2 shiftwidth=2 expandtab tabstop=2
*/
